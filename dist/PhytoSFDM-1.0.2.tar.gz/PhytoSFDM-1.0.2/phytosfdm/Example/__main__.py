#!/usr/bin/env python
# -*- coding: utf-8 -*-


from .example import main

main()